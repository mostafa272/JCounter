﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined('_JEXEC') or die();

class modJcounterHelper{
static function getToday($params)
    {
    $arts=$params->get('catid');
    $where="";
     $db=JFactory::getDBO();
     if($params->get('source')=='create')
     {
     $where=' WHERE DATE(a.created)=CURDATE()';
     }
     else if($params->get('source')=='publish')
     { $where=' WHERE DATE(a.publish_up)=CURDATE()';
     }
     if($params->get('only_publish')=='1')
     { $where=$where.' AND a.state=1';
     }
     if($arts!="")
     {
       $a=implode(',',$arts);
      $where=$where.' AND a.catid IN('.$a.')';
     }
     $query='SELECT COUNT(a.id) as tedad FROM #__content AS a'.$where;
     $db->setQuery($query);
     $instance=$db->loadObjectList();
     foreach($instance as $i)
     $result=$i->tedad;
      return $result;
  }
 static function getYesterday($params)
    {
    $arts=$params->get('catid');
    $where="";
     $db=JFactory::getDBO();

     if($params->get('source')=='create')
     {
     $where=' WHERE DATE(a.created)=SUBDATE(CURDATE(),1)';
     }
     else if($params->get('source')=='publish')
     { $where=' WHERE DATE(a.publish_up)=SUBDATE(CURDATE(),1)';
     }
     if($params->get('only_publish')=='1')
     { $where=$where.' AND a.state=1';
     }
     if($arts!="")
     {  $a=implode(',',$arts);
      $where=$where.' AND a.catid IN('.$a.')';
     }
     $query='SELECT COUNT(a.id) as tedad FROM #__content AS a'.$where;
     $db->setQuery($query);
     $instance=$db->loadObjectList();
     foreach($instance as $i)
     $result=$i->tedad;
      return $result;
  }
 static function getWeekly($params)
    {
    $arts=$params->get('catid');
    $where="";
     $db=JFactory::getDBO();
     if($params->get('source')=='create')
     {
     $where=' WHERE DATE(a.created)>SUBDATE(CURDATE(),7)';
     }
     else if($params->get('source')=='publish')
     { $where=' WHERE DATE(a.publish_up)>SUBDATE(CURDATE(),7)';
     }
     if($params->get('only_publish')=='1')
     { $where=$where.' AND a.state=1';
     }
     if($arts!="")
     {  $a=implode(',',$arts);
      $where=$where.' AND a.catid IN('.$a.')';
     }
     $query='SELECT COUNT(a.id) as tedad FROM #__content AS a'.$where;
     $db->setQuery($query);
     $instance=$db->loadObjectList();
     foreach($instance as $i)
     $result=$i->tedad;
      return $result;

  }
 static function getMonthly($params)
    {
    $arts=$params->get('catid');
    $where="";
     $db=JFactory::getDBO();
     if($params->get('source')=='create')
     {
     $where=' WHERE DATE(a.created)>SUBDATE(CURDATE(),30)';
     }
     else if($params->get('source')=='publish')
     { $where=' WHERE DATE(a.publish_up)>SUBDATE(CURDATE(),30)';
     }
     if($params->get('only_publish')=='1')
     { $where=$where.' AND a.state=1';
     }
     if($arts!="")
     {  $a=implode(',',$arts);
      $where=$where.' AND a.catid IN('.$a.')';
     }
     $query='SELECT COUNT(a.id) as tedad FROM #__content AS a'.$where;
     $db->setQuery($query);
     $instance=$db->loadObjectList();
     foreach($instance as $i)
     $result=$i->tedad;
      return $result;
  }
 static function getTotal($params)
    {
    $arts=$params->get('catid');
    $where="";
     $db=JFactory::getDBO();

     if($params->get('only_publish')=='1')
     { $where=$where.' AND a.state=1';
     }
     if($arts!="")
     {  $a=implode(',',$arts);
      $where=$where.' AND a.catid IN('.$a.')';
     }
     $query='SELECT COUNT(a.id) as tedad FROM #__content AS a WHERE 1'.$where;
     $db->setQuery($query);
     $instance=$db->loadObjectList();
     foreach($instance as $i)
     $result=$i->tedad;
      return $result;
  }

}