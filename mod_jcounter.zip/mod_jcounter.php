﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined('_JEXEC') or die();
if(!defined('DS'))
{  define('DS',DIRECTORY_SEPARATOR);
}
// Include the helper class
require_once dirname(__FILE__) . DS . 'helper.php';
jimport( 'joomla.application.module.helper' );
$show_today=$params->get('show_today');
$show_yesterday=$params->get('show_yesterday');
$show_week=$params->get('show_week');
$show_month=$params->get('show_month');
$show_total=$params->get('show_total');
$today= modJcounterHelper::getToday($params);
$yesterday=modJcounterHelper::getYesterday($params);
$week=modJcounterHelper::getWeekly($params);
$month=modJcounterHelper::getMonthly($params);
$total=modJcounterHelper::getTotal($params);

// Display the template
require(JModuleHelper::getLayoutPath('mod_jcounter'));

?>